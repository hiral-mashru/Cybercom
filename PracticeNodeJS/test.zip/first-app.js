console.log('Hello')

const fs = require('fs');
fs.writeFileSync('Hello.txt','Heyy')

