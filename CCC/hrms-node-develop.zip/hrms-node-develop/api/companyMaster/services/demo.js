module.exports={
  serviceName:()=>{
    //Your service codes will go here
    return "service has been called"
  }
}
