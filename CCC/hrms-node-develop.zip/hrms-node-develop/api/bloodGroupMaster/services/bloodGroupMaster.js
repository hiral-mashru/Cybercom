module.exports = {
 bloodGroupMaster: (req,res)=> {
  console.log("This is service bloodGroupMaster")
  res.send('This is service bloodGroupMaster')
 }
}