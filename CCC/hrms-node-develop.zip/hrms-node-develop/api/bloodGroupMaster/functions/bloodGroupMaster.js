module.exports = {
 bloodGroupMaster: ()=> {
  console.log("This is function bloodGroupMaster")
 }
}