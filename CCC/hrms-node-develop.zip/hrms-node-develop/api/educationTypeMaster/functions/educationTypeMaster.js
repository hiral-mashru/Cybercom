module.exports = {
 educationTypeMaster: ()=> {
  console.log("This is function educationTypeMaster")
 }
}