module.exports = {
 educationTypeMaster: (req,res)=> {
  console.log("This is service educationTypeMaster")
  res.send('This is service educationTypeMaster')
 }
}