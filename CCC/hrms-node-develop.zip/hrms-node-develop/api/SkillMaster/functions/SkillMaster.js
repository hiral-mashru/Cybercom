module.exports={
  functionName:()=>{
    return 'Your function data';
  }
}