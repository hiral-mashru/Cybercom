define({
  "name": "HRMS API DOCUMENTATION",
  "version": "0.1.0",
  "description": "RESTFUL API DOCUMENTATION FOR HRMS",
  "title": "API docs",
  "url": "http://localhost:8000",
  "template": {
    "forceLanguage": "en"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-06-03T10:51:24.689Z",
    "url": "https://apidocjs.com",
    "version": "0.28.1"
  }
});
