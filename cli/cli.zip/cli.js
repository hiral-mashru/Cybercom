#!/usr/bin/env node

console.log( "Hello!" );

var fs = require('fs');
var chalk = require('chalk')

const [,,...args] = process.argv // to parse command line arguments

const[type,...modulle] = args

if(type==='create-module') {
    if(modulle){
        if (!fs.existsSync(String(modulle))) {
            fs.mkdirSync(String(modulle));
        }
    } else {
        console.log(chalk.black.bgYellowBright('WARNING:')+'Provide a module name')
    }
} else {
    console.log(chalk.black.bgYellowBright('WARNING:')+' Type is not provided')
}


